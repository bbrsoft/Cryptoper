<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
   
   public function __construct()
   {
      parent::__construct();
      $this->load->model('identity_model', 'identity', true);
      $this->load->model('banner_model', 'banner', true);
      $this->load->model('posting_model', 'posting', true);
      $this->load->model('category_model', 'category', true);
      $this->load->model('User_model');
      $this->load->model('album_model', 'album');
   }
   
  public function index() {
        $data['favicon'] = $this->identity->getIdentity();
        $data['title'] = 'Home';
        $data['banner'] = $this->banner->getBanner();
        $data['album'] = $this->album->getAlbum();

        $isLogin = $this->session->userdata('user_logged_in');
        if($isLogin){
            $data['coin'] = $this->session->userdata('coin');
            $data['email'] = $this->session->userdata('email');
            $data['username'] = $this->session->userdata('username');
             // Fetch posts by title (username)
            $data['myhistorybet'] = $this->posting->get_posts_by_title($data['username']);
            $data['historyClose'] = $this->posting->get_posts_by_close_number();
            
        } else {
            $data['coin'] = 0;
        }

        $data['page'] = 'home';
        $this->load->view('front/layouts/app', $data);
    }


    public function get_trading_history() {
        $ca = $this->input->get('ca');
          $trades = $this->posting->getRecentTrades($ca);
          echo json_encode($trades);
       }
       
      public function place_bet() {
            $username = $this->session->userdata('username');
            $result = $this->input->post('result');
            $ca = $this->input->post('ca');
            $bet = $this->input->post('bet');
            $user = $this->User_model->get_user_by_username($username);
            $coin = $user->coin;
        
            // Periksa apakah coin user cukup untuk taruhan
            if ($coin >= $bet) {
                
                $new_coin = $coin - $bet;
                $this->User_model->update_coin($username, $new_coin);
        

                $data = [
                    'title' => $username,
                    'seo_title' => $result,
                    'content' => $bet,
                    'id_category' => $ca,
                    'date' => date('Y-m-d H:i:s'),
                    'is_active' => "N",
                    'choice' => "N",
                ];
            
                $insert = $this->posting->place_bet($data);
            
                if ($insert) {
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false]);
                }
            }
        }
   
        public function authenticate() {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
        
            $user = $this->User_model->login($username, $password);
        
            if ($user && password_verify($password, $user->password)) {
                $userdata = array(
                    'user_id' => $user->id,
                    'username' => $user->username,
                    'email' => $user->email,
                    'coin' => $user->coin,
                    'user_logged_in' => true
                );
                $this->session->set_userdata($userdata);
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'errors' => 'Invalid username or password']);
            }
        }
    
    public function register() {
        // Atur rules validasi
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');

        if ($this->form_validation->run() == FALSE) {
            // Jika validasi gagal
            echo json_encode(['success' => false, 'errors' => validation_errors()]);
        } else {
            // Jika validasi berhasil
            $email = $this->input->post('email');
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            $data = [
                'email' => $email,
                'username' => $username,
                'password' => password_hash($password, PASSWORD_BCRYPT), // Simpan password yang sudah di-hash
                'role' => 'user',
                'coin' => 0,
                'created_on' => time()
            ];

            $insert = $this->User_model->register($data);

            if ($insert) {
                // Atur session userdata setelah registrasi berhasil
                $session_data = [
                    'user_id' => $this->db->insert_id(), // Dapatkan ID pengguna yang baru saja didaftarkan
                    'username' => $username,
                    'email' => $email,
                    'role' => 'user',
                    'user_logged_in' => TRUE
                ];

                $this->session->set_userdata($session_data);

                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'errors' => 'Registration failed.']);
            }
        }
    }
    
    public function logout() {
        // Hapus data sesi pengguna
        $this->session->unset_userdata('user_logged_in');
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('coin');

        // Tambahkan pesan flash jika diperlukan
        $this->session->set_flashdata('success', 'You have been logged out successfully');

        // Arahkan ke halaman login
        redirect('./'); // Ganti 'auth/login' dengan path ke halaman login Anda
    }
    
   public function get_user_coin() {
    if ($this->session->userdata('user_logged_in')) {
            $user_id = $this->session->userdata('user_id');
            $this->load->model('User_model');
            $coin = $this->User_model->get_coin_by_id($user_id);
            echo json_encode(['coin' => number_format($coin, 6, ',', '.')]);
        } else {
            echo json_encode(['coin' => 0]);
        }
    }


    public function get_end_time() {
        $name = $this->input->get('name');
        $end_time = $this->album->get_end_time_by_name($name);
    
        if ($end_time) {
            echo json_encode(['end_time' => $end_time]);
        } else {
            echo json_encode(['end_time' => 'Not found']);
        }
    }
    
    public function botmaster(){
        $data['albums'] = $this->album->getAlb();
        $this->load->view('front/layouts/bot' , $data);
    }
    
    public function botprogress() {
         // Get current time in HH:mm format
       
        date_default_timezone_set('Asia/Jakarta');

        // Create a DateTime object for the current time in the source timezone (e.g., UTC)
        $sourceTimezone = new DateTimeZone('UTC');
        $currentTimeUTC = new DateTime('now', $sourceTimezone);
        
        // Convert the current time to the target timezone (e.g., Asia/Jakarta)
        $targetTimezone = new DateTimeZone('Asia/Jakarta');
        $currentTimeUTC->setTimezone($targetTimezone);
        
        // Get the formatted time in the target timezone
        $currentTime = $currentTimeUTC->format('H:i');
        // Fetch all albums (or you can optimize by fetching only necessary fields)
        $albums = $this->album->getAlb(); // Assuming this method exists to fetch albums
        $d = null;
        // Loop through albums to check 'photo' field
        foreach ($albums as $album) {
             
            
            if ($album->photo == $currentTime) {
                 // Update posting status
                $winDigits = str_split($album->win);
                $winPostings = $this->posting->getWinPostings($winDigits);
                
                // Array untuk melacak ID posting yang menang
                $winningPostIds = array();
                
                foreach ($winPostings as $posting) {
                    // Periksa apakah seo_title cocok dengan salah satu digit dalam album->win
                    if (in_array($posting->seo_title, $winDigits)) {
                        // Tandai posting ini sebagai menang
                        $winningPostIds[] = $posting->id;
                
                        // Update posting choice menjadi Y
                        $this->db->where('id', $posting->id);
                        $this->db->update('posting', array('choice' => 'Y', 'is_active' => 'Y'));
                
                        // Hitung 150% dari nilai posting->content
                        // $bonusMulti = $album->bonus / 100;
                        $bonusCoin = $posting->content * 1.5;
                
                        // Update coin di tabel users berdasarkan title dari postingan
                        $this->db->set('coin', 'coin + ' . $bonusCoin, FALSE);
                        $this->db->where('username', $posting->title);
                        $this->db->update('users');
                    }
                }
                
                // Update semua postingan dengan choice 'N' yang tidak menang menjadi 'L' (kalah)
                if (!empty($winningPostIds)) {
                    $this->db->where_not_in('id', $winningPostIds);
                }
                $this->db->where('choice', 'N');
                $this->db->update('posting', array('choice' => 'L', 'is_active' => 'N'));
            
                // Insert posting baru
                $newPosting = array(
                    'thread' => $album->win,
                    'date' => date('Y-m-d H:i:s'),
                    'id_category' => $album->id
                );
                $this->db->insert('posting', $newPosting);
                
                // Update other postings to lose
                // $this->posting->updatePostingLose($randomWin);
                
                $randomWin = rand(1000, 9999);
                $this->album->updateWin($album->id, $randomWin);
                
                // Mengatur waktu saat ini untuk Laos (+2 menit dari saat ini)
                if ($album->album_name == 'Laos') {
                    $currentTime = date('H:i', strtotime('+2 minutes'));
                    $this->album->updateLaos($album->id, $currentTime);
                }
                
                if($d==null){
                    $d = "Telah Diubah Mark ".$album->album_name;
                }
                
            }
            
          
            
        }

        echo $currentTime." Bot processing Checked. ".$d;
    }
       
}

/* End of file Home.php */
