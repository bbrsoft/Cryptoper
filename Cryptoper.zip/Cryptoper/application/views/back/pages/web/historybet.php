<div class="container">
   <div class="row">
      <div class="col">
         <h3 class="page-header"><?= $title ?></h3>
      </div>
   </div>

   <button class="btn btn-outline-secondary btn-sm mt-3"onclick="reload_table()">
      <i class="fas fa-sync-alt"></i> Reload
   </button>

   <br><br>

   <div class="table-responsive">
      <table id="tableHistory" class="table table-striped table-bordered"  cellspacing="0" width="100%">
         <thead>
         <tr>
            <th>#</th>
            <th>bet</th>
            <th>amount</th>
            <th>Username</th>
            <th>status</th>
            <th>Action</th>
         </tr>
         </thead>
         <tbody>
         
         </tbody>
      </table>
   </div>

</div>
