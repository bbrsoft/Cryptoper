<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bot Progress</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Bot Progress Trigger <?php echo date('Y-m-d');?></h1>
    <p>  <ul>
            <?php foreach ($albums as $album): ?>
                <li>
                    <h2><?php echo $album->album_name; ?></h2>
                    <p>S: <?php echo $album->album_seo; ?></p>
                    <p>Time: <?php echo $album->photo; ?></p>
                </li>
            <?php endforeach; ?>
        </ul></p>
    <div id="result"></div>
    <div id="nextInterval">Next interval in: 30 seconds</div>

    <script>
        $(document).ready(function() {
            let intervalTime = 30; // Interval time in seconds
            let countdown = intervalTime;

            // Function to update the countdown
            function updateCountdown() {
                $('#nextInterval').text('Next interval in: ' + countdown + ' seconds');
                countdown--;
                if (countdown < 0) {
                    countdown = intervalTime;
                }
            }

            // Function to make the AJAX call
            function runBotProgress() {
                $.ajax({
                    url: './botprogress', // Replace with your actual URL
                    type: 'GET',
                    success: function(response) {
                        const now = new Date();
                        const timestamp = now.toLocaleTimeString();
                      $('#result').html('<p>[' + timestamp + '] ' + response + '</p>');
                    },
                    error: function(xhr, status, error) {
                        const now = new Date();
                        const timestamp = now.toLocaleTimeString();
                        // $('#result').prepend('<p>[' + timestamp + '] Error: ' + error + '</p>');
                    }
                });
            }

            // Set interval to run every 30 seconds
            setInterval(runBotProgress, intervalTime * 1000);
            setInterval(updateCountdown, 1000);

            // Trigger the bot progress on page load
            runBotProgress();
        });
    </script>
</body>
</html>
