<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Album_model extends CI_Model {

   protected $table = 'album';

   public function getAlbum()
   {
      return $this->db->get($this->table)->result();
   }
   
   
   public function getAlb() {
        $query = $this->db->get('album'); // Replace 'albums' with your actual table name
        return $query->result();
    }

    public function updateWin($albumId, $winValue) {
        $this->db->where('id', $albumId); // Assuming 'id' is the primary key
        $this->db->update('album', ['win' => $winValue]);
    }
    
    public function updateLaos($albumId, $time) {
        $this->db->where('id', $albumId); // Assuming 'id' is the primary key
        $this->db->update('album', ['photo' => $time]);
    }
    
    
   private function _get_datatables_query()
   {
      $this->db->from($this->table);

      $i = 0;
      foreach ($this->column_search as $item) // loop kolom yang dibutuhkan untuk pencarian
      {
         if($_POST['search']['value']) // jika datatable mengirimkan pencarian dengan metode POST
         {
            if($i===0) // looping pertama
            {
               $this->db->group_start(); // open bracket. query Where dengan OR clause lebih baik dengan group start dan end.
               $this->db->like($item, $_POST['search']['value']);
            }
            else
            {
               $this->db->or_like($item, $_POST['search']['value']);
            }

            if(count($this->column_search) - 1 == $i) // looping terakhir
               $this->db->group_end(); // close bracket
         }
         $i++;
      }

      if(isset($_POST['order'])) // here order processing
      {
         $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
      } 
      else if(isset($this->order))
      {
         $order = $this->order;
         $this->db->order_by(key($order), $order[key($order)]);
      }
   }
   
      function count_filtered()
   {
      $this->_get_datatables_query();
      $query = $this->db->get();
      return $query->num_rows();
   }

   public function count_all()
   {
      $this->db->from($this->table);
      return $this->db->count_all_results();
   }

   public function uploadImage()
   {
		$fileName = slugify($this->input->post('album_name', true));

      $config = [
        'upload_path'     => './images/album',
        'file_name'       => $fileName . '-' . round(microtime(true) * 10),
        'allowed_types'   => 'jpg|jpeg|gif|png|JPG|PNG',
        'max_size'        => '3000',
        'max_width'       => 0,
        'max_height'      => 0,
        'overwrite'       => true,
        'file_ext_tolower'=> true
      ];

      $this->load->library('upload', $config);

      if(!$this->upload->do_upload('photo')){
         $data['error_string'] = 'Upload error: '.$this->upload->display_errors('',''); 
         exit();
		}
		return $this->upload->data('file_name');
	}

   public function deleteImage($fileName){
      if(file_exists("./images/album/$fileName")){
         unlink("./images/album/$fileName");
      }
   }
   
   public function get_end_time_by_name($name) {
        $this->db->select('photo');
        $this->db->from('album');
        $this->db->where('album_seo', $name);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->row()->photo;
        } else {
            return null;
        }
    }
}

/* End of file Album_model.php */
