<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
    
    
    private function _get_datatables_query()
   {
      $this->db->from($this->table);

      $i = 0;
      foreach ($this->column_search as $item) // loop kolom yang dibutuhkan untuk pencarian
      {
         if($_POST['search']['value']) // jika datatable mengirimkan pencarian dengan metode POST
         {
            if($i===0) // looping pertama
            {
               $this->db->group_start(); // open bracket. query Where dengan OR clause lebih baik dengan group start dan end.
               $this->db->like($item, $_POST['search']['value']);
            }
            else
            {
               $this->db->or_like($item, $_POST['search']['value']);
            }

            if(count($this->column_search) - 1 == $i) // looping terakhir
               $this->db->group_end(); // close bracket
         }
         $i++;
      }

      if(isset($_POST['order'])) // here order processing
      {
         $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
      } 
      else if(isset($this->order))
      {
         $order = $this->order;
         $this->db->order_by(key($order), $order[key($order)]);
      }
   }

   function get_datatables()
   {
      $this->_get_datatables_query();
      if($_POST['length'] != -1)
      $this->db->limit($_POST['length'], $_POST['start']);
      $query = $this->db->get();
      return $query->result();
   }

   function count_filtered()
   {
      $this->_get_datatables_query();
      $query = $this->db->get();
      return $query->num_rows();
   }

   public function count_all()
   {
      $this->db->from($this->table);
      return $this->db->count_all_results();
   }
    
    public function login($username, $password) {
        $this->db->where('username', $username);
        $query = $this->db->get('users');
        
        if ($query->num_rows() == 1) {
            $user = $query->row();
            if (password_verify($password, $user->password)) {
                return $user;
            }
        }
        return false;
    }

    
    public function register($data) {
        return $this->db->insert('users', $data);
    }
    
    public function get_by_id($id) {
          $this->db->where('id', $id);
          return $this->db->get('users')->row();
      }
      
      
    public function updateUserCoin($username, $amount) {
    $this->db->set('coin', 'coin + ' . $amount, FALSE);
    $this->db->where('username', $username);
    $this->db->update('users');
}
  
    public function get_coin_by_id($id)
    {
        $this->db->select('coin');
        $this->db->from('users');
        $this->db->where('id', $id);
        $query = $this->db->get();
    
        if ($query->num_rows() > 0) {
            return $query->row()->coin;
        } else {
            return 0; // Atau nilai default lainnya
        }
    }
    
    public function update($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update('users', $data);
    }
    
    public function get_user_by_username($username) {
        $this->db->where('username', $username);
        $query = $this->db->get('users');
        return $query->row();
    }

    public function update_coin($username, $new_coin) {
        $this->db->where('username', $username);
        $this->db->update('users', ['coin' => $new_coin]);
    }


}
